<?php

namespace App;

class Config {

	const DB_HOST = "localhost";

	const DB_NAME = "user_management";

	const DB_USERNAME = "root";

	const DB_PASSWORD = "";

}